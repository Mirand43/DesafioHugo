package com.antonio.crudtarefas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudTarefasApplicationTests {

	@Test
	void contextLoads() {
	}

}
